# -*- coding: utf-8 -*-
import MySQLdb
import functools
import time
import datetime
import urllib
import urllib2

#dbg=True
dbg=False
class DataUtil:
###################
    @staticmethod
    def GetDb():
        conn = None
        conn = MySQLdb.connect(host="irweb", port=3306,user="outEtherUser", passwd="outuserEtherCapDotCom12345",db="news_db",charset="utf8")
        #conn = MySQLdb.connect(host="m4000i.hebe.grid.sina.com.cn", port=4000,user="finance_news", passwd="1f365e06fa2c7b1",db="finance_news",charset="utf8")
        return conn

    @staticmethod
    def GetDb_project():
        conn = None
        #conn = MySQLdb.connect(host="127.0.0.1", port=3306,user="root", passwd="dashboard54321",db="news_db",charset="utf8")
        #conn = MySQLdb.connect(host="rdsbeeia2yna2ym.mysql.rds.aliyuncs.com", port=3306,user="jackyhou", passwd="testHou123456",db="wutong",charset="utf8")
        conn = MySQLdb.connect(host="rdsbeeia2yna2ym.mysql.rds.aliyuncs.com", port=3306,user="server2", passwd="Yc6Ymfzd-ceM7frOplqznp6jNE_SILsk",db="wutong",charset="utf8")
        return conn
    @staticmethod
    def GetDb_db(db):
        conn = None
        conn = MySQLdb.connect(host="irweb", port=3306,user="outEtherUser", passwd="outuserEtherCapDotCom12345",db=db,charset="utf8")
        #conn = MySQLdb.connect(host="m4000i.hebe.grid.sina.com.cn", port=4000,user="finance_news", passwd="1f365e06fa2c7b1",db="finance_news",charset="utf8")
        return conn


    @staticmethod
    def get_investorlist(uid):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            sql = "SELECT i.userid,u.name,u.`company` ,i.fundid FROM `wutong`.`investor_info` as i inner join user as u on i.userid=u.userid where i.userid >"+str(uid)+"   ORDER BY i.`userid` LIMIT 1000;"
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

    @staticmethod
    def get_project_attributes(projectid):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            sql = "SELECT projectid,attributeid,value,id FROM `wutong`.`project_category_backend` where projectid= "+str(projectid)+" ORDER BY `id` "
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "add into cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )

            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()


    @staticmethod
    def update_team_info__ (projectid,teaminfo_by_editor):
        cursor = None
        conn = None
        try:
            conn = DataUtil.GetDb()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8")

            sql ="update team_tab set teaminfo='%s' where projectid=%d;" % (teaminfo_by_editor,projectid)
            print sql#[0:32]

            cursor.execute(sql)
            conn.commit()
            #print 'add ok',projectid

        except MySQLdb.Error, e:
            print 'insert team error:', e.args[0], e.args[1]
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

    @staticmethod
    def add_team_categoryinfo(projectid,categorystr,matchedstr,teaminfo_by_editor):
        cursor = None
        conn = None
        try:
            conn = DataUtil.GetDb()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8")
            existed=DataAccess.get_team(projectid)
            if(existed==0):
                sql ="insert into team_tab(categorystr,catematchedstr,projectid,teaminfo)  values ('%s','%s',%d,'%s');" % (categorystr,matchedstr,projectid,teaminfo_by_editor)
                #sql ="update team_tab set categorystr='%s',catematchedstr='%s' where projectid=%d;" % (categorystr,matchedstr,projectid)
            else:
                sql ="update team_tab set categorystr='%s',catematchedstr='%s' where projectid=%d;" % (categorystr,matchedstr,projectid)
            if dbg: print sql#[0:32]

            cursor.execute(sql)
            conn.commit()
            #print 'add ok',projectid

        except MySQLdb.Error, e:
            print 'insert team error:', e.args[0], e.args[1]
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

    '''
    author:chunliang
    create date:2015-12-08
    description:返回时间段内的applogs结果
    return: results,like [{'logid':1},{'userId':1},...]
    sql:select logId,type,subtype,userId,objectId,localTime from investor_app_log l where l.type='RELATED_PROJECT'
    and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='2015-12-07 00:00:00' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='2015-12-08 24:00:00' order by logId desc limit 5;
    '''
    @staticmethod
    def get_applogs(logtype,from_time,to_time,limit):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='RELATED_PROJECT' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='"+logtype+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";
            sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='"+logtype+"' and l.localTime >='"+str(from_time)+"' and l.localTime <='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    '''
    author:chunliang
    create date:2015-12-09
    description:返回时间段内的推荐recommendWithWeight 结果
    return: results,like [{'logid':1},{'userId':1},...]
    sql:select id,investor,project,time from recommendWithWeight l
    where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='2015-12-07 00:00:00' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='2015-12-08 24:00:00' order by id desc limit 5;
    '''
    @staticmethod
    def get_recommend_result(from_time,to_time,limit):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_db('cf')

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            sql_which ="select w.id,w.which from whichRecommend w limit 1;"
            cursor.execute(sql_which)
            results=cursor.fetchall()
            #print results
            which_table=''
            if results:
                which_table = results[0][1]
            else:
                which_table = 'onlineRecommend'
            #sql = "select logId,type,subtype,userId,objectId,localTime from investor_app_log l where l.type='RELATED_PROJECT' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            #sql="select id,investor,project,time from recommendWithWeight l where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by id desc limit "+str(limit)+";";
            #sql="select id,investor,project,time from "+which_table+" l where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by id desc limit "+str(limit)+";";

            sql="select id,investor,project,time from "+which_table+" l where l.time>='"+str(from_time)+"' and l.time <='"+str(to_time)+"' order by id desc limit "+str(limit)+";";
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    '''
    author:chunliang
    create date:2015-12-09
    description:返回时间段内的推荐recommendWithWeight 结果
    return: results,like [{'logid':1},{'userId':1},...]
    sql:select id,investor,project,time from recommendWithWeight l
    where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='2015-12-07 00:00:00' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='2015-12-08 24:00:00' order by id desc limit 5;
    special:old version,unuse
    update date:2015-12-14
    '''
    @staticmethod
    def get_recommend_result_topN(uid,topn):
        rec_topn_ids=[]
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_db('cf')

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            sql_which ="select w.id,w.which from whichRecommend w limit 1;"
            cursor.execute(sql_which)
            results=cursor.fetchall()
            #print results
            which_table=''
            if results:
                which_table = results[0][1]
            else:
                which_table = 'onlineRecommend'
            #sql = "select logId,type,subtype,userId,objectId,localTime from investor_app_log l where l.type='RELATED_PROJECT' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            #sql="select id,investor,project,time from recommendWithWeight l where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by id desc limit "+str(limit)+";";
            #sql="select id,investor,project,time from "+which_table+" l where date_format(l.time,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.time,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by id desc limit "+str(limit)+";";

            #sql ="select investor,project from "+which_table+" order by weight desc limit "+str(topn)+";"
            sql ="select project from "+which_table+" where investor='"+str(uid)+"' order by weight desc limit "+str(topn)+";"
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                for r in results:
                    rec_topn_ids.append(r[0])
            return rec_topn_ids

            #return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

            #sql = " SELECT userid,company FROM `wutong`.`user` where userid> "+str(uid)+" ORDER BY `userId` LIMIT 50"

    '''
    author:chunliang
    create date:2015-12-08
    description:返回时间段内的applogs结果
    return: results,like [{'logid':1},{'userId':1},...]
    sql:select logId,type,subtype,userId,objectId,localTime from investor_app_log l where l.type='RELATED_PROJECT'
    and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='2015-12-07 00:00:00' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='2015-12-08 24:00:00' order by logId desc limit 5;
    special: unuse
    update date:12.14
    '''
    @staticmethod
    def get_applogs_cf(from_time,to_time,limit):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='RELATED_PROJECT' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='"+logtype+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            sql="""
            select l.logId,l.type,l.subtype,l.userId,l.objectId,l.localTime from `investor_app_log` l
            where l.type in ('APPLY_MEETING','COLLECT_PROJECT','PROJECT_DETAIL','PROJECT_VIEW','PROJECT_BP','PROJECT_EXPOSE')
            and
            l.localTime between '{0}' and '{1}' order by l.logId desc limit {2};
            """.format(from_time,to_time,limit)
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    

    @staticmethod
    def get_applogs_cf_from_logid(logid,limit=1000):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='RELATED_PROJECT' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            #sql = "select logId,type,subtype,userId,objectId,`localTime` from investor_app_log l where l.type='"+logtype+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')>='"+str(from_time)+"' and date_format(l.localTime,'%Y-%m-%d %H:%i:%S')<='"+str(to_time)+"' order by logId desc limit "+str(limit)+";";

            sql="""
            select l.logId,l.type,l.subtype,l.userId,l.objectId,l.localTime from `investor_app_log` l
            where 
            l.logId > '{0}' and l.type in ('APPLY_MEETING','COLLECT_PROJECT','PROJECT_VIEW','PROJECT_BP') order by l.logId LIMIT {1};
            """.format(logid,limit)
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    @staticmethod
    def get_user_ethercap():
        #time_day  = time.strftime('%Y-%m-%d',time.localtime(time.time()-86400*10))
        #global g_user_ethercap
        conn = None
        cursor=None
        _result_dict={}
        try:
            conn = DataUtil.GetDb_project()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            sql = " SELECT userid,name,company FROM `wutong`.`user` where company= '以太资本';"
            #sql = " SELECT userid,name,company FROM `wutong`.`user` where userid> "+str(uid)+" ORDER BY `userId` LIMIT 50"
            #sql = " SELECT userid,company FROM `wutong`.`user`;"
            if dbg: print sql

            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                for r in results:
                    uid=r[0]
                    name=r[1].encode('utf8','ignore').strip()
                    company=r[2].encode('utf-8','ignore').strip()
                    if company=="以太资本":
                        #g_user_ethercap[uid]=1
                        _result_dict[uid]=name
            return _result_dict

        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "add into cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1] )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    @staticmethod
    def get_user_all_list():
        _result_dict = {}
        sql ="select distinct(userId) from investor_app_log;"
        results = DataUtil.db_query(sql)
        if results:
            #print results
            for r in results:
                _userId = r[0]
                _result_dict[_userId] = 1
        return _result_dict
#------------------------v2------------------
    @staticmethod
    def get_applogs_cf_from_logid2(logId,limit=1000):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            
            sql="""
            select
            l.logId,l.userId,u.name,l.ObjectId,l.type,p.title,l.creationTime
            from
            investor_app_log l 
            left join 
            user u on u.userId=l.userId left join project p on p.projectId=l.ObjectId  
            where 
            l.type in ('APPLY_MEETING','COLLECT_PROJECT','PROJECT_VIEW','PROJECT_BP') and l.logId >{0} order by l.logId limit {1};
            """.format(logId,limit)
            if dbg: print sql
            #print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
     
    @staticmethod
    def get_user_exposed(uid):
        #time_day  = time.strftime('%Y-%m-%d',time.localtime(time.time()-86400*10))
        #global g_user_ethercap
        conn = None
        cursor=None
        _result_dict={}
        try:
            conn = DataUtil.GetDb()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql = " SELECT userid,name,company FROM `wutong`.`user` where company= '以太资本';"
            #sql = " SELECT userid,name,company FROM `wutong`.`user` where userid> "+str(uid)+" ORDER BY `userId` LIMIT 50"
            #sql = " SELECT userid,company FROM `wutong`.`user`;"
            sql="select userid,projectid from user_track_record where exposedcount>0 and userid="+str(uid)+";";
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                for r in results:
                    uid=r[0]
                    projectId=r[1]
                    _result_dict[projectId]=uid
            return _result_dict
            #return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "add into cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1] )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    #----------------add at 2016.1.14
    @staticmethod
    def get_user_meetinged(userid):
        #time_day  = time.strftime('%Y-%m-%d',time.localtime(time.time()-86400*10))
        #global g_user_ethercap
        conn = None
        cursor=None
        _result_dict={}
        try:
            conn = DataUtil.GetDb_project()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql="select userid,projectid from user_track_record where exposedcount>0 and userid="+str(uid)+";";
            sql = "SELECT investorId,projectid FROM `wutong`.`meeting` where `investorId` ="+str(userid)+" ORDER BY `meetingId`;"; 
            if dbg: print sql
            #print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                for r in results:
                    uid=r[0]
                    projectId=r[1]
                    _result_dict[projectId]=uid
            return _result_dict
            #return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "add into cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1] )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    #-----------------
    # add by zcl at 2016.1.14
    #
    # offline in fact online 
    @staticmethod
    def get_project_online():
        #time_day  = time.strftime('%Y-%m-%d',time.localtime(time.time()-86400*10))
        #global g_user_ethercap
        conn = None
        cursor=None
        _result_dict={}
        try:
            conn = DataUtil.GetDb_project()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            #sql = "SELECT investorId,projectid FROM `wutong`.`meeting` where `investorId` ="+str(userid)+" ORDER BY `meetingId`;";
            sql="SELECT distinct(projectId) from `project`  where status2  in (4000,5000);"
            if dbg: print sql
            #print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            if results:
                for r in results:
                    projectId=r[0]
                    _result_dict[projectId]=1
            return _result_dict
            #return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "add into cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1] )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
    #-----------------
    @staticmethod
    def get_applogs_cf_from_logid2_count():
        _result = None
        sql ="select count(l.logId) from investor_app_log l left join user u on u.userId=l.userId left join project p on p.projectId=l.ObjectId where l.type in ('APPLY_MEETING','COLLECT_PROJECT','PROJECT_VIEW','PROJECT_BP') and l.logId >1 order by l.logId limit 1;"
        results = DataUtil.db_query(sql)
        if results:
            for r in results:
                _result = r[0]
        return _result
    @staticmethod
    def get_applogs_cf_from_logid2_lastId():
        _result = None
        sql ="select l.logId from investor_app_log l left join user u on u.userId=l.userId left join project p on p.projectId=l.ObjectId where l.type in ('APPLY_MEETING','COLLECT_PROJECT','PROJECT_VIEW','PROJECT_BP') order by l.logId desc limit 1;"
        results = DataUtil.db_query(sql)
        if results:
            for r in results:
                _result = r[0]
        return _result
    @staticmethod
    def db_query(sql):
        conn = None
        cursor=None
        try:
            conn = DataUtil.GetDb_project()

            cursor = conn.cursor()
            cursor.execute("set NAMES utf8 ")
            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

    @staticmethod
    def get_project_term(pid, limit):
        conn = None
        cursor = None
        try:
            conn = DataUtil.GetDb()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8")
            sql="""select title, category, terms, content_for_snippet, pid, projectid from project_tab_ir where pid > {0} limit {1};""".format(pid, limit)

            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()

    @staticmethod
    def get_project_info(projectid):
        conn = None
        cursor = None
        try:
            conn = DataUtil.GetDb_project()
            cursor = conn.cursor()
            cursor.execute("set NAMES utf8")
            sql="""select name from project_team_info where projectId = {0};""".format(projectid)

            if dbg: print sql
            cursor.execute(sql)
            results = cursor.fetchall()
            return results
        except MySQLdb.Error, e:
            #logger.info("get url mysqldb error!")
            print "select from cluster mysqldb error! --%d:  %s" % ( e.args[0], e.args[1]   )
            return None
        finally:
            if(cursor!=None):
                cursor.close()
            if(conn!= None):
                conn.close()
                
    #def get_all_userIds():
    #    sql ="select "      
if __name__=='__main__':
    print '--main--'
    #ether_user = DataUtil.get_user_ethercap()
    #print ether_user
    #exposedUser = DataUtil.get_user_exposed(3)
    #print exposedUser
    #-----------test meetingedUser---
    #meetingedUser = DataUtil.get_user_meetinged(3)
    #print meetingedUser
    
    project_onlines = DataUtil.get_project_online()
    print project_onlines
    
    #t= DataUtil.get_applogs_cf_from_logid2(1,1)
    #print t
    #t= DataUtil.get_applogs_cf_from_logid2_count()
    #print t
    #t= DataUtil.get_applogs_cf_from_logid2_lastId()
    #print t

    #t= DataUtil.get_user_all_list()
    #print t
